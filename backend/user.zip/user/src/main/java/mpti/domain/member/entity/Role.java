package mpti.domain.member.entity;

public enum Role {
    MEMBER,ADMIN,TRAINER
}
